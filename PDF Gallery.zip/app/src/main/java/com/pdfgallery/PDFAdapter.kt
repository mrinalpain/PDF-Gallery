package com.pdfgallery

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PDFAdapter(
    private var pdfFiles: List<PDFFile>,
    private var isGridView: Boolean = true,
    private val onItemClick: (PDFFile) -> Unit
) : RecyclerView.Adapter<PDFAdapter.PDFViewHolder>() {

    class PDFViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivThumbnail: ImageView = itemView.findViewById(R.id.ivThumbnail)
        val tvFileName: TextView = itemView.findViewById(R.id.tvFileName)
        val tvFileSize: TextView = itemView.findViewById(R.id.tvFileSize)
        val tvFileDate: TextView = itemView.findViewById(R.id.tvFileDate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PDFViewHolder {
        val layoutId = if (isGridView) R.layout.item_pdf_grid else R.layout.item_pdf_list
        val view = LayoutInflater.from(parent.context).inflate(layoutId, parent, false)
        return PDFViewHolder(view)
    }

    override fun onBindViewHolder(holder: PDFViewHolder, position: Int) {
        val pdfFile = pdfFiles[position]
        
        holder.tvFileName.text = pdfFile.name
        holder.tvFileSize.text = holder.itemView.context.getString(R.string.file_size, pdfFile.getFormattedSize())
        holder.tvFileDate.text = holder.itemView.context.getString(R.string.file_date, pdfFile.getFormattedDate())
        
        holder.itemView.setOnClickListener {
            onItemClick(pdfFile)
        }
    }

    override fun getItemCount(): Int = pdfFiles.size

    fun updateData(newPdfFiles: List<PDFFile>) {
        pdfFiles = newPdfFiles
        notifyDataSetChanged()
    }
    
    fun updateViewMode(isGrid: Boolean) {
        isGridView = isGrid
        notifyDataSetChanged()
    }
}