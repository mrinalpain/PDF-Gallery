package com.pdfgallery

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.github.barteksc.pdfviewer.PDFView
import com.google.android.material.appbar.MaterialToolbar
import java.io.File

class PDFViewerActivity : AppCompatActivity() {
    
    private lateinit var pdfView: PDFView
    private lateinit var toolbar: MaterialToolbar
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pdf_viewer)
        
        pdfView = findViewById(R.id.pdfView)
        toolbar = findViewById(R.id.toolbar)
        
        val pdfPath = intent.getStringExtra("pdf_path")
        val pdfName = intent.getStringExtra("pdf_name")
        
        setupToolbar(pdfName ?: "PDF Viewer")
        
        if (pdfPath != null) {
            loadPDF(pdfPath)
        } else {
            Toast.makeText(this, "Error: PDF path not found", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
    
    private fun setupToolbar(title: String) {
        setSupportActionBar(toolbar)
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            setDisplayShowHomeEnabled(true)
            setTitle(title)
        }
        
        toolbar.setNavigationOnClickListener {
            onBackPressed()
        }
    }
    
    private fun loadPDF(pdfPath: String) {
        try {
            val file = File(pdfPath)
            if (file.exists()) {
                pdfView.fromFile(file)
                    .enableSwipe(true)
                    .swipeHorizontal(false)
                    .enableDoubletap(true)
                    .defaultPage(0)
                    .enableAnnotationRendering(false)
                    .password(null)
                    .scrollHandle(null)
                    .enableAntialiasing(true)
                    .spacing(0)
                    .load()
            } else {
                Toast.makeText(this, "PDF file not found", Toast.LENGTH_SHORT).show()
                finish()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error loading PDF: ${e.message}", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}