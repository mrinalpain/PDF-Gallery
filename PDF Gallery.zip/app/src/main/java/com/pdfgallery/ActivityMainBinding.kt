package com.pdfgallery

import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton

class ActivityMainBinding private constructor(
    val root: View,
    val toolbar: MaterialToolbar,
    val swipeRefresh: SwipeRefreshLayout,
    val recyclerView: RecyclerView,
    val emptyView: View,
    val permissionView: View,
    val btnGrantPermission: MaterialButton
) {
    companion object {
        fun inflate(inflater: LayoutInflater): ActivityMainBinding {
            val root = inflater.inflate(R.layout.activity_main, null)
            return ActivityMainBinding(
                root = root,
                toolbar = root.findViewById(R.id.toolbar),
                swipeRefresh = root.findViewById(R.id.swipeRefresh),
                recyclerView = root.findViewById(R.id.recyclerView),
                emptyView = root.findViewById(R.id.emptyView),
                permissionView = root.findViewById(R.id.permissionView),
                btnGrantPermission = root.findViewById(R.id.btnGrantPermission)
            )
        }
    }
}