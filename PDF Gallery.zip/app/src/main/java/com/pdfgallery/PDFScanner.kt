package com.pdfgallery

import android.content.Context
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class PDFScanner(private val context: Context) {
    
    suspend fun scanForPDFs(): List<PDFFile> = withContext(Dispatchers.IO) {
        val pdfFiles = mutableListOf<PDFFile>()
        
        // Scan common directories
        val directories = listOf(
            Environment.getExternalStorageDirectory(),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
            context.getExternalFilesDir(null)
        ).filterNotNull()
        
        directories.forEach { directory ->
            scanDirectory(directory, pdfFiles)
        }
        
        pdfFiles.sortedByDescending { it.lastModified }
    }
    
    private fun scanDirectory(directory: File, pdfFiles: MutableList<PDFFile>) {
        try {
            directory.listFiles()?.forEach { file ->
                when {
                    file.isDirectory -> scanDirectory(file, pdfFiles)
                    file.isFile && file.extension.lowercase() == "pdf" -> {
                        pdfFiles.add(PDFFile(file))
                    }
                }
            }
        } catch (e: SecurityException) {
            // Handle permission issues
        }
    }
}