package com.pdfgallery

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private lateinit var pdfAdapter: PDFAdapter
    private lateinit var pdfScanner: PDFScanner
    private var allPdfFiles = listOf<PDFFile>()
    private var filteredPdfFiles = listOf<PDFFile>()
    private var isGridView = true
    private var groupBy = GroupBy.DATE
    
    enum class GroupBy { NAME, DATE, SIZE }
    
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.all { it }) {
            loadPDFs()
        } else {
            showPermissionView()
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupToolbar()
        setupRecyclerView()
        setupSwipeRefresh()
        pdfScanner = PDFScanner(this)
        
        binding.btnGrantPermission.setOnClickListener {
            requestPermissions()
        }
        
        checkPermissionsAndLoad()
    }
    
    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
    }
    
    private fun setupRecyclerView() {
        pdfAdapter = PDFAdapter(emptyList(), isGridView) { pdfFile ->
            openPDF(pdfFile)
        }
        binding.recyclerView.adapter = pdfAdapter
        updateLayoutManager()
    }
    
    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setOnRefreshListener {
            loadPDFs()
        }
    }
    
    private fun updateLayoutManager() {
        binding.recyclerView.layoutManager = if (isGridView) {
            GridLayoutManager(this, 2)
        } else {
            LinearLayoutManager(this)
        }
    }
    
    private fun checkPermissionsAndLoad() {
        if (hasStoragePermissions()) {
            loadPDFs()
        } else {
            showPermissionView()
        }
    }
    
    private fun hasStoragePermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
    }
    
    private fun requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
            intent.data = Uri.parse("package:$packageName")
            startActivity(intent)
        } else {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                )
            )
        }
    }
    
    private fun loadPDFs() {
        binding.swipeRefresh.isRefreshing = true
        lifecycleScope.launch {
            try {
                allPdfFiles = pdfScanner.scanForPDFs()
                filteredPdfFiles = allPdfFiles
                groupAndSortPDFs()
                updateUI()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Error loading PDFs: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }
    
    private fun groupAndSortPDFs() {
        filteredPdfFiles = when (groupBy) {
            GroupBy.NAME -> filteredPdfFiles.sortedBy { it.name.lowercase() }
            GroupBy.DATE -> filteredPdfFiles.sortedByDescending { it.lastModified }
            GroupBy.SIZE -> filteredPdfFiles.sortedByDescending { it.size }
        }
    }
    
    private fun updateUI() {
        if (filteredPdfFiles.isEmpty()) {
            showEmptyView()
        } else {
            showRecyclerView()
            pdfAdapter.updateData(filteredPdfFiles)
        }
    }
    
    private fun showPermissionView() {
        binding.permissionView.visibility = android.view.View.VISIBLE
        binding.recyclerView.visibility = android.view.View.GONE
        binding.emptyView.visibility = android.view.View.GONE
    }
    
    private fun showEmptyView() {
        binding.emptyView.visibility = android.view.View.VISIBLE
        binding.recyclerView.visibility = android.view.View.GONE
        binding.permissionView.visibility = android.view.View.GONE
    }
    
    private fun showRecyclerView() {
        binding.recyclerView.visibility = android.view.View.VISIBLE
        binding.emptyView.visibility = android.view.View.GONE
        binding.permissionView.visibility = android.view.View.GONE
    }
    
    private fun openPDF(pdfFile: PDFFile) {
        val intent = Intent(this, PDFViewerActivity::class.java)
        intent.putExtra("pdf_path", pdfFile.path)
        intent.putExtra("pdf_name", pdfFile.name)
        startActivity(intent)
    }
    
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        
        val searchItem = menu.findItem(R.id.action_search)
        val searchView = searchItem.actionView as SearchView
        
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean = false
            
            override fun onQueryTextChange(newText: String?): Boolean {
                filterPDFs(newText ?: "")
                return true
            }
        })
        
        return true
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_grid_view -> {
                isGridView = true
                pdfAdapter.updateViewMode(isGridView)
                updateLayoutManager()
                true
            }
            R.id.action_list_view -> {
                isGridView = false
                pdfAdapter.updateViewMode(isGridView)
                updateLayoutManager()
                true
            }
            R.id.action_group_name -> {
                groupBy = GroupBy.NAME
                groupAndSortPDFs()
                updateUI()
                true
            }
            R.id.action_group_date -> {
                groupBy = GroupBy.DATE
                groupAndSortPDFs()
                updateUI()
                true
            }
            R.id.action_group_size -> {
                groupBy = GroupBy.SIZE
                groupAndSortPDFs()
                updateUI()
                true
            }
            R.id.action_refresh -> {
                loadPDFs()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    
    private fun filterPDFs(query: String) {
        filteredPdfFiles = if (query.isEmpty()) {
            allPdfFiles
        } else {
            allPdfFiles.filter { 
                it.name.contains(query, ignoreCase = true) 
            }
        }
        groupAndSortPDFs()
        updateUI()
    }
    
    override fun onResume() {
        super.onResume()
        if (hasStoragePermissions() && allPdfFiles.isEmpty()) {
            loadPDFs()
        }
    }
}